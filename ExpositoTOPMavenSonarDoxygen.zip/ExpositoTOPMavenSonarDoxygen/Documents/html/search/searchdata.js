var indexSectionsWithContent =
{
  0: "abcdefghimnoprstuvwxy",
  1: "bempt",
  2: "e",
  3: "bempt",
  4: "abcefghimnprstuw",
  5: "abdefimnoprsvwxy"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Namespaces",
  3: "Archivos",
  4: "Funciones",
  5: "Variables"
};

